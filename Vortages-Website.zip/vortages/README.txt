VORTAGES WEBSITE

Files:
- index.html: the website homepage

Preview:
Open index.html in a browser.

Publish free with GitHub Pages:
1. Sign in to https://github.com and create a PUBLIC repository named vortages.
2. Upload index.html from this folder to the repository root and commit it.
3. Open repository Settings > Pages.
4. Choose Deploy from a branch, select main and /(root), then Save.
5. Wait a few minutes. Your website address will look like https://YOUR-USERNAME.github.io/vortages/

Note: The site is a static starter website. The anime descriptions are introductory, and the updates section does not fetch live news.
